package iss.java.mail;
import javax.mail.MessagingException;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.reagle.bean.MailBean;

import com.reagle.util.others.MailUtil;

/**
 
 * �ʼ��ӿ�ʵ��
 
 **/
public class MailServiceImpl2014302580065 implements IMailService {
	 public static void main(String[] args) {
	        MailReceiver smr = new MailReceiver("pop3.163.com","781339835@qq.com","entersymwrm");
	        try {
	            smr.receive();
	        } catch (MessagingException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	    }
    private static Logger log = LogManager.getLogger(MailServiceImpl2014302580065.class);
    
    
    private static final int COREPOOLSIZE = 10; 
    private static final int MAXIMUMPOOLSIZE = 20; //���������
    
    private static ThreadPoolExecutor pool;
    private static BlockingQueue<Runnable> queue = new LinkedBlockingQueue<Runnable>();
    
    static {
        /** 
         *  ʹ��JDK�е��̳߳�
         */
        pool = new ThreadPoolExecutor(COREPOOLSIZE, MAXIMUMPOOLSIZE, 2, TimeUnit.MINUTES, queue); 
    }
    @Override
    public void sendMail(String sendMailAddr, String sendMailPwd,
            List<String> ccs, List<String> tos, String subject,
            String content, List<String> accessories, String mailType, String operMan, String memo) {
       MailThread mail = new MailThread();
       mail.init(sendMailAddr, sendMailPwd, ccs, tos, subject, content, accessories, mailType, operMan, memo);
       pool.execute(mail); 
    }
    /**
     * @Program Name : reaglews.com.reagle.server.impl.MailServiceImpl.java
     * �����ʼ��߳�
     */
    class MailThread implements Runnable {
        private Logger logger = LogManager.getLogger(MailThread.class);
        
        private List<String> ccs;
        private List<String> tos;
        private List<String> accessories;
        
        private String sendMailAddr;
        private String sendMailPwd;
        private String subject;
        private String content;
        private String mailType;
        private String operMan;
        private String memo;
        
        private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        /**
         *  ��ʼ���߳�����
         * @param sendMailAddr 
         * @param sendMailPwd
         * @param ccs ���ͺ���
         * @param tos �ռ���
         * @param subject ����
         * @param content ����
         * @param accessories ����
         *
         */
        public void init(String sendMailAddr, String sendMailPwd,
                List<String> ccs, List<String> tos, String subject,
                String content, List<String> accessories, String mailType, String operMan, String memo){
            this.sendMailAddr = sendMailAddr;
            this.sendMailPwd = sendMailPwd;
            this.ccs = ccs;
            this.tos = tos;
            this.subject = subject;
            this.content = content;
            this.accessories = accessories;
            this.mailType = mailType;
            this.operMan = operMan;
            this.memo = memo;
        }
        @Override
        public void run() {
            logger.info("�����ʼ���ʼ" + sdf.format(new Date()));
            int id = 0;
            String flag = "0";  //������
            String msg = "";      //������Ϣ
            boolean res = false;// ���ͽ��
            try {
                id = getSeqNo();
                ccs.addAll(queryCCsByMailType(mailType)); // ������Ҫ���͵������ַ
                // ʹ��Ĭ�ϵ�����
                if(StringUtils.isBlank(sendMailAddr)) {
                    sendMailAddr = MailUtil.getConfigValue(DEFAULT_SEND);
                    sendMailPwd = MailUtil.getConfigValue(DEFAULT_SEND_PWD);
                }
                
                // ����������ʼ���־
                saveLog(sendMailAddr, ccs, tos, subject, content, accessories, mailType, operMan, memo, id);
                
                // У������, ȥ�����������ַ
                if(!validate(sendMailAddr, sendMailPwd, ccs, tos, subject, content, accessories)) {
                    logger.error("У���ʼ�����ʧ��");
                    return;
                }
                // ��ȡ�ʼ�����
                MailBean mail = getMailInstance(sendMailAddr, sendMailPwd, ccs, tos, subject, content, accessories);
                
                // �����ʼ�
                res = mail.send();
                flag = res ? "1" : "2";
                if(!res) msg = "δ֪����,����ʧ��";
                
                // ���·��ͼ�¼
                modifyLog(msg, flag, id);
                
            } catch (Exception e) {
                e.printStackTrace();
                logger.error(e.getMessage(), e);
                modifyLog(e.getMessage(), "2", id);
            }
            logger.info("�����ʼ�����" + sdf.format(new Date()));    
        }
        
        /**
         * ��ȡ�ʼ�����ʵ��
         */
        private MailBean getMailInstance(String sendMailAddr, String sendMailPwd,
                List<String> ccs, List<String> tos, String subject,
                String content, List<String> accessories){
            // ��ȡSMTP��ַ
            String mailHost = MailUtil.getMail2SMTP(sendMailAddr);
            
            // �����ʼ�
            MailBean mail = new MailBean(subject, 
                    sendMailAddr, 
                    sendMailPwd,
                    tos,  // �ռ���
                    content, 
                    MailUtil.getConfigValue(CHARACTERCONFIG), 
                    mailHost, 
                    accessories,    // ����
                    MailUtil.getConfigValue(CHECKSEND),
                    ccs  //����
            );
            
            return mail;
        }
        
        private boolean validate(String sendMailAddr, String sendMailPwd,
                List<String> transmitMails, List<String> takeMail, String subject,
                String content, List<String> multiparts){
            boolean res = true;
            if(!MailUtil.isEmail(sendMailAddr)) res = false;
            // ����������
            cancelErrorMailAddr(transmitMails); 
            cancelErrorMailAddr(takeMail);
            
            return res;
        }
        
        private void cancelErrorMailAddr(List<String> list) {
            if(null == list || list.isEmpty()) return;
            List<String> back = new ArrayList<String>(list);
            for (String email : back) {
                if(!MailUtil.isEmail(email)) {
                    list.remove(email);
                    log.info("�Ƴ������ʼ�:" + email);
                }
            }
        }

        private int getSeqNo() {
            String seqSql = "select seq_mail.nextval from dual";
            BigDecimal b =  (BigDecimal) new DbUtilsTemplate().findBy(seqSql, 1);
            return b.intValue();
        }
        
        private boolean saveLog(String sendMail, List<String> ccs, List<String> tos, String subject,
                String content, List<String> accessories, String mailType, String operman, String memo, int id) {
            
            StringBuffer sql = new StringBuffer(); 
            sql.append(" INSERT INTO mail_send_detail ");
            sql.append(" (ID, sendmail, senddate, tos, ccs, subject, CONTEXT, status, ");
            sql.append(" mailtype, accessories, operman, operdate,opermemo) values(?, ?, sysdate, ?, ?, ?, ?, '0', ?, ?, ?, sysdate, ?)");
            
            String[] params = {
                    String.valueOf(id),
                    sendMail, 
                    Arrays.toString(ccs.toArray()).replace("[", "").replace("]", ""),
                    Arrays.toString(tos.toArray()).replace("[", "").replace("]", ""), 
                    subject,
                    content,
                    mailType,
                    Arrays.toString(accessories.toArray()).replace("[", "").replace("]", ""),
                    operman,
                    memo
            };
            
            return (1 == new DbUtilsTemplate().update(sql.toString(), params)); 
        }
        
        private boolean modifyLog(String memo, String flag, int id){
            String sql ="update mail_send_detail set status=?, memo = ? where id = ?";
            return (1 == new DbUtilsTemplate().update(sql, 
                    new String[]{flag, memo, String.valueOf(id)}));
        }
        // ��ѯ�ʼ������£� ��Ҫ���͵�
        private List<String> queryCCsByMailType(String mailType) {
            List<String> list = new ArrayList<String>();
            String sql = "select ccs from dm_mail_type where dm01=?";
            String emails =  (String) new DbUtilsTemplate().findBy(sql, 1, mailType);
            if(StringUtils.isNotBlank(emails)) {
                 list = Arrays.asList(emails.split(";"));
            }
            return list;
        }
    }
}